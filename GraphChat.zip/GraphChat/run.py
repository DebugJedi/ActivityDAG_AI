import graph_agent
import memory_builder


if __name__ == "__main__":
    memory_builder.main()
    # graph_agent.main("The very last words say that the 5 by 5 centered difference matrix is not invertible. Write down the 5 equations Cx=b. Find a combination of left sides that gives zero. What combination of  b1 , b2 , b3, b4 , b5 must be zero? (The 5 column lie on a '4-dimensional hyperplane' in 5-dimensional space.)")

    # Insert User query here
    graph_agent.main("")