/**
 * CriticalPath AI - Portfolio Style
 * Enhanced with vibrant gradients and modern UX
 */

const els = {
  // File Upload
  dropzone: document.getElementById("dropzone"),
  fileInput: document.getElementById("fileInput"),
  fileStatus: document.getElementById("fileStatus"),
  hintText: document.getElementById("hintText"),
  
  // Projects
  projectGrid: document.getElementById("projectGrid"),
  modalProjectGrid: document.getElementById("modalProjectGrid"),
  projectCount: document.getElementById("projectCount"),
  selectFirstBtn: document.getElementById("selectFirstBtn"),

  // Views
  onboardingCard: document.getElementById("onboardingCard"),
  chatCard: document.getElementById("chatCard"),

  // Active Project
  activeProjectName: document.getElementById("activeProjectName"),

  // Header
  headerTitle: document.getElementById("headerTitle"),
  headerSubtitle: document.getElementById("headerSubtitle"),

  // Topics
  topicsList: document.getElementById("topicsList"),
  newTopicBtn: document.getElementById("newTopicBtn"),

  // Chat
  messages: document.getElementById("messages"),
  messageInput: document.getElementById("messageInput"),
  sendBtn: document.getElementById("sendBtn"),

  // Controls
  changeProjectBtn: document.getElementById("changeProjectBtn"),
  resetBtn: document.getElementById("resetBtn"),
  exportBtn: document.getElementById("exportBtn"),
  importBtn: document.getElementById("importBtn"),
  importInput: document.getElementById("importInput"),

  // Modal
  modalBackdrop: document.getElementById("modalBackdrop"),
  closeModalBtn: document.getElementById("closeModalBtn"),

  // Mobile
  sidebar: document.getElementById("sidebar"),
  mobileMenuBtn: document.getElementById("mobileMenuBtn"),

  // Context Menu
  topicContextMenu: document.getElementById("topicContextMenu"),
  renameTopicBtn: document.getElementById("renameTopicBtn"),
  deleteTopicBtn: document.getElementById("deleteTopicBtn"),
};

const BACKEND_CHAT_URL = "/api/chat";
const storageKey = "criticalpath_ai_state_v3";

const state = loadState() || {
  files: [],
  projects: [],
  activeProject: null,
  topicsByProject: {},
  activeTopicByProject: {}
};

let currentContextTopicId = null;

init();

function init(){
  wireUI();
  renderAll();
  
  if (typeof marked !== 'undefined') {
    marked.setOptions({
      breaks: true,
      gfm: true,
    });
  }
}

function wireUI(){
  // Drag & drop
  els.dropzone.addEventListener("dragover", (e) => {
    e.preventDefault();
    els.dropzone.classList.add('drag-over');
  });
  
  els.dropzone.addEventListener("dragleave", () => {
    els.dropzone.classList.remove('drag-over');
  });
  
  els.dropzone.addEventListener("drop", async (e) => {
    e.preventDefault();
    els.dropzone.classList.remove('drag-over');
    const files = Array.from(e.dataTransfer.files || []).filter(f => f.name.endsWith(".md"));
    if (!files.length) {
      toast("Please drop .md files only", 'warning');
      return;
    }
    await ingestFiles(files);
  });

  els.fileInput.addEventListener("change", async (e) => {
    const files = Array.from(e.target.files || []).filter(f => f.name.endsWith(".md"));
    if (!files.length) {
      toast("Please select .md files", 'warning');
      return;
    }
    await ingestFiles(files);
    els.fileInput.value = "";
  });

  // Chat
  els.sendBtn.addEventListener("click", () => sendMessage());
  els.messageInput.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && !e.shiftKey){
      e.preventDefault();
      sendMessage();
    }
  });
  els.messageInput.addEventListener("input", () => autosize(els.messageInput));

  // Topics
  els.newTopicBtn.addEventListener("click", () => {
    if (!state.activeProject) {
      toast("Select a project first", 'warning');
      return;
    }
    const t = createTopic(state.activeProject, "New topic");
    setActiveTopic(state.activeProject, t.id);
    persist();
    renderAll();
    els.messageInput.focus();
    toast("New topic created", 'success');
  });

  // Projects
  els.changeProjectBtn.addEventListener("click", () => openProjectModal());
  els.selectFirstBtn.addEventListener("click", () => {
    if (state.projects.length){
      selectProject(state.projects[0].proj_short_name);
    }
  });

  // Controls
  els.resetBtn.addEventListener("click", () => {
    if (!confirm("Reset local UI state (projects, topics, messages)?")) return;
    localStorage.removeItem(storageKey);
    toast("State reset. Reloading...", 'info');
    setTimeout(() => location.reload(), 1000);
  });

  els.closeModalBtn.addEventListener("click", closeProjectModal);
  els.modalBackdrop.addEventListener("click", (e) => {
    if (e.target === els.modalBackdrop) closeProjectModal();
  });

  // Export/Import
  els.exportBtn.addEventListener("click", exportState);
  els.importBtn.addEventListener("click", () => els.importInput.click());
  els.importInput.addEventListener("change", (e) => {
    const file = e.target.files[0];
    if (file) importState(file);
    els.importInput.value = "";
  });

  // Mobile
  els.mobileMenuBtn.addEventListener("click", () => {
    els.sidebar.classList.toggle('open');
  });

  document.addEventListener("click", (e) => {
    if (window.innerWidth <= 768 && 
        els.sidebar.classList.contains('open') &&
        !els.sidebar.contains(e.target) &&
        !els.mobileMenuBtn.contains(e.target)) {
      els.sidebar.classList.remove('open');
    }
  });

  // Context menu
  els.renameTopicBtn.addEventListener("click", () => {
    if (currentContextTopicId && state.activeProject) {
      const topic = getTopics(state.activeProject).find(t => t.id === currentContextTopicId);
      if (topic) {
        const newTitle = prompt("Enter new topic name:", topic.title);
        if (newTitle && newTitle.trim()) {
          renameTopic(state.activeProject, currentContextTopicId, newTitle.trim());
          toast("Topic renamed", 'success');
        }
      }
    }
    hideContextMenu();
  });

  els.deleteTopicBtn.addEventListener("click", () => {
    if (currentContextTopicId && state.activeProject) {
      deleteTopic(state.activeProject, currentContextTopicId);
    }
    hideContextMenu();
  });

  document.addEventListener("click", (e) => {
    if (!els.topicContextMenu.contains(e.target) && !e.target.closest('.topic-menu-btn')) {
      hideContextMenu();
    }
  });

  // Keyboard shortcuts
  document.addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
      e.preventDefault();
      els.messageInput.focus();
    }

    if (e.key === 'Escape') {
      if (!els.modalBackdrop.hidden) {
        closeProjectModal();
      } else if (!els.topicContextMenu.hidden) {
        hideContextMenu();
      }
    }
  });
}

async function ingestFiles(files){
  const totalSize = files.reduce((sum, f) => sum + f.size, 0);
  const maxSize = 10 * 1024 * 1024;

  if (totalSize > maxSize) {
    toast('Files too large. Maximum 10MB total.', 'error');
    return;
  }

  els.fileStatus.innerHTML = `
    <span class="loading-spinner"></span>
    <span>Loading ${files.length} file(s)...</span>
  `;

  const loaded = [];

  try {
    for (const f of files){
      const text = await f.text();
      loaded.push({ name: f.name, text });
    }

    const map = new Map(state.files.map(x => [x.name, x]));
    for (const f of loaded) map.set(f.name, f);
    state.files = Array.from(map.values());

    state.projects = extractProjectsFromFiles(state.files);

    els.fileStatus.innerHTML = `
      <span class="status-icon">✓</span>
      <span>Loaded ${state.files.length} file(s), ${state.projects.length} project(s)</span>
    `;
    els.selectFirstBtn.disabled = state.projects.length === 0;

    persist();
    renderAll();

    toast(`Successfully loaded ${files.length} file(s)`, 'success');
  } catch (err) {
    els.fileStatus.innerHTML = `
      <span class="status-icon">✕</span>
      <span>Error loading files</span>
    `;
    toast(`Error loading files: ${err.message}`, 'error');
  }
}

function extractProjectsFromFiles(files){
  const preferred = files.find(f => /PROJECT\.md$/i.test(f.name)) || files.find(f => /PROJECT/i.test(f.name));
  const candidates = preferred ? [preferred, ...files.filter(f => f !== preferred)] : files;

  let projects = [];
  for (const f of candidates){
    const found = extractProjectsFromMarkdownTable(f.text);
    if (found.length){
      projects = found;
      break;
    }
  }

  const seen = new Set();
  const uniq = [];
  for (const p of projects){
    const key = (p.proj_short_name || "").trim();
    if (!key || seen.has(key)) continue;
    seen.add(key);
    uniq.push(p);
  }

  uniq.sort((a,b) => (a.proj_short_name || "").localeCompare(b.proj_short_name || "", undefined, {numeric:true}));
  return uniq;
}

function extractProjectsFromMarkdownTable(md){
  const lines = md.split(/\r?\n/);

  let headerLineIdx = -1;
  for (let i=0; i<lines.length; i++){
    const line = lines[i].trim();
    if (line.startsWith("|") && line.includes("proj_short_name")){
      headerLineIdx = i;
      break;
    }
  }
  if (headerLineIdx === -1) return [];

  const headerCells = splitMdRow(lines[headerLineIdx]);
  const colIndex = (name) => headerCells.findIndex(h => h.trim() === name);

  const idxProjId = colIndex("proj_id");
  const idxShort = colIndex("proj_short_name");
  const idxPlanStart = colIndex("plan_start_date");
  const idxPlanEnd = colIndex("plan_end_date");
  const idxScdEnd = colIndex("scd_end_date");

  const rows = [];
  for (let i=headerLineIdx+2; i<lines.length; i++){
    const line = lines[i].trim();
    if (!line.startsWith("|")) continue;
    const cells = splitMdRow(line);
    if (cells.every(c => c.trim() === "")) continue;

    const proj_short_name = safeCell(cells, idxShort);
    if (!proj_short_name) continue;

    rows.push({
      proj_id: safeCell(cells, idxProjId),
      proj_short_name,
      plan_start_date: safeCell(cells, idxPlanStart),
      plan_end_date: safeCell(cells, idxPlanEnd),
      scd_end_date: safeCell(cells, idxScdEnd),
    });
  }

  return rows;
}

function splitMdRow(line){
  const trimmed = line.trim();
  const noEdges = trimmed.replace(/^\|/, "").replace(/\|$/, "");
  return noEdges.split("|").map(s => s.trim());
}

function safeCell(cells, idx){
  if (idx < 0) return "";
  return (cells[idx] ?? "").trim();
}

function renderAll(){
  renderProjects();
  renderSidebar();
  renderChat();
  renderHeader();
}

function renderProjects(){
  els.projectGrid.innerHTML = "";
  els.modalProjectGrid.innerHTML = "";
  els.projectCount.textContent = `${state.projects.length} found`;

  for (const p of state.projects){
    const card = projectCard(p, false);
    els.projectGrid.appendChild(card);

    const card2 = projectCard(p, true);
    els.modalProjectGrid.appendChild(card2);
  }
}

function projectCard(p, isModal){
  const div = document.createElement("div");
  div.className = "project-card";
  div.innerHTML = `
    <div class="project-name">${escapeHtml(p.proj_short_name || "Unknown")}</div>
    <div class="project-details">
      ${p.proj_id ? `<span class="detail-badge">ID: ${escapeHtml(p.proj_id)}</span>` : ""}
      ${p.plan_start_date ? `<span class="detail-badge">Start: ${escapeHtml(shortDate(p.plan_start_date))}</span>` : ""}
      ${p.scd_end_date ? `<span class="detail-badge">End: ${escapeHtml(shortDate(p.scd_end_date))}</span>` : ""}
    </div>
  `;
  div.addEventListener("click", () => {
    selectProject(p.proj_short_name);
    if (isModal) closeProjectModal();
  });
  return div;
}

function renderSidebar(){
  els.activeProjectName.textContent = state.activeProject || "No project selected";

  els.topicsList.innerHTML = "";
  if (!state.activeProject) return;

  const topics = getTopics(state.activeProject);
  const activeTopicId = state.activeTopicByProject[state.activeProject] || (topics[0]?.id ?? null);

  for (const t of topics){
    const div = document.createElement("div");
    div.className = "topic-item" + (t.id === activeTopicId ? " active" : "");
    div.innerHTML = `
      <div class="topic-header">
        <div class="topic-title">${escapeHtml(t.title)}</div>
        <button class="topic-menu-btn" data-topic-id="${t.id}">⋮</button>
      </div>
      <div class="topic-meta">${t.messages.length} message(s)</div>
    `;
    
    div.addEventListener("click", (e) => {
      if (!e.target.classList.contains('topic-menu-btn')) {
        setActiveTopic(state.activeProject, t.id);
        persist();
        renderAll();
      }
    });

    const menuBtn = div.querySelector('.topic-menu-btn');
    menuBtn.addEventListener("click", (e) => {
      e.stopPropagation();
      showContextMenu(e, t.id);
    });

    els.topicsList.appendChild(div);
  }
}

function renderHeader(){
  if (!state.activeProject){
    els.headerTitle.textContent = "Welcome to CriticalPath AI";
    els.headerSubtitle.textContent = "Upload your P6 schedule exports and start analyzing critical paths, float, and milestones with AI assistance.";
    els.onboardingCard.hidden = false;
    els.chatCard.hidden = true;
    return;
  }

  const activeTopic = getActiveTopic(state.activeProject);

  els.headerTitle.textContent = `${state.activeProject} • ${activeTopic?.title || "Topic"}`;
  els.headerSubtitle.textContent = "Ask questions about your schedule - critical path, float, constraints, milestones, and more.";
  els.onboardingCard.hidden = true;
  els.chatCard.hidden = false;
}

function renderChat(){
  els.messages.innerHTML = "";
  if (!state.activeProject) return;

  let topic = getActiveTopic(state.activeProject);
  if (!topic){
    const t = createTopic(state.activeProject, "General");
    setActiveTopic(state.activeProject, t.id);
    persist();
    topic = t;
  }

  if (!topic.messages || !topic.messages.length) {
    els.messages.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">💬</div>
        <div class="empty-title">Start Your Analysis</div>
        <div class="empty-subtitle">
          Ask about critical path, total float, free float, schedule durations, milestones, constraints, 
          or any schedule-related questions. I'm here to help analyze your P6 data.
        </div>
      </div>
    `;
    return;
  }

  for (const m of topic.messages){
    els.messages.appendChild(renderMessage(m.role, m.content, m.ts));
  }

  requestAnimationFrame(() => {
    els.messages.scrollTop = els.messages.scrollHeight;
  });
}

function renderMessage(role, content, ts){
  const wrap = document.createElement("div");
  wrap.className = `message ${role}`;

  const avatar = document.createElement("div");
  avatar.className = "message-avatar";
  avatar.textContent = role === "user" ? "U" : "AI";

  const contentDiv = document.createElement("div");
  contentDiv.className = "message-content";
  
  const bubble = document.createElement("div");
  bubble.className = "message-bubble";
  
  if (role === "assistant" && typeof marked !== 'undefined') {
    try {
      bubble.innerHTML = marked.parse(content);
    } catch (err) {
      bubble.textContent = content;
    }
  } else {
    bubble.textContent = content;
  }

  const time = document.createElement("div");
  time.className = "message-time";
  time.textContent = ts ? formatTimestamp(ts) : "";

  contentDiv.appendChild(bubble);
  contentDiv.appendChild(time);

  wrap.appendChild(avatar);
  wrap.appendChild(contentDiv);

  return wrap;
}

function formatTimestamp(ts) {
  const date = new Date(ts);
  const now = new Date();
  const diff = now - date;
  
  if (diff < 60000) return 'Just now';
  
  if (diff < 3600000) {
    const mins = Math.floor(diff / 60000);
    return `${mins}m ago`;
  }
  
  if (date.toDateString() === now.toDateString()) {
    return date.toLocaleTimeString('en-US', { 
      hour: 'numeric', 
      minute: '2-digit' 
    });
  }
  
  if (diff < 604800000) {
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      hour: 'numeric', 
      minute: '2-digit' 
    });
  }
  
  return date.toLocaleDateString('en-US', { 
    month: 'short', 
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit'
  });
}

function selectProject(projShortName){
  state.activeProject = projShortName;

  const topics = getTopics(projShortName);
  if (!topics.length){
    const t = createTopic(projShortName, "General");
    setActiveTopic(projShortName, t.id);
  } else if (!state.activeTopicByProject[projShortName]){
    setActiveTopic(projShortName, topics[0].id);
  }

  persist();
  renderAll();
  els.messageInput.focus();
  
  toast(`Switched to project: ${projShortName}`, 'success');
}

function openProjectModal(){
  if (!state.projects.length){
    toast("No projects detected yet. Upload your .md files first.", 'warning');
    return;
  }
  els.modalBackdrop.hidden = false;
}

function closeProjectModal(){
  els.modalBackdrop.hidden = true;
}

function getTopics(project){
  return state.topicsByProject[project] || [];
}

function getActiveTopic(project){
  const topics = getTopics(project);
  const id = state.activeTopicByProject[project] || topics[0]?.id;
  return topics.find(t => t.id === id) || null;
}

function setActiveTopic(project, topicId){
  state.activeTopicByProject[project] = topicId;
}

function createTopic(project, title){
  const t = {
    id: "t_" + Math.random().toString(36).slice(2) + Date.now(),
    title: title || "Topic",
    messages: []
  };
  if (!state.topicsByProject[project]) state.topicsByProject[project] = [];
  state.topicsByProject[project].unshift(t);
  return t;
}

function renameTopic(project, topicId, newTitle) {
  const topics = getTopics(project);
  const topic = topics.find(t => t.id === topicId);
  if (topic) {
    topic.title = newTitle || 'Topic';
    persist();
    renderAll();
  }
}

function deleteTopic(project, topicId) {
  if (!confirm('Delete this topic and all messages?')) return;
  
  const topics = state.topicsByProject[project] || [];
  state.topicsByProject[project] = topics.filter(t => t.id !== topicId);
  
  const remaining = state.topicsByProject[project];
  if (remaining.length) {
    setActiveTopic(project, remaining[0].id);
  } else {
    const newTopic = createTopic(project, 'General');
    setActiveTopic(project, newTopic.id);
  }
  
  persist();
  renderAll();
  toast('Topic deleted', 'success');
}

function showContextMenu(e, topicId) {
  e.preventDefault();
  e.stopPropagation();
  
  currentContextTopicId = topicId;
  
  const menu = els.topicContextMenu;
  menu.hidden = false;
  
  const rect = e.target.getBoundingClientRect();
  menu.style.left = rect.left + 'px';
  menu.style.top = (rect.bottom + 5) + 'px';
}

function hideContextMenu() {
  els.topicContextMenu.hidden = true;
  currentContextTopicId = null;
}

async function sendMessage(){
  if (!state.activeProject) {
    toast("Select a project first", 'warning');
    return;
  }
  
  const text = (els.messageInput.value || "").trim();
  if (!text) return;

  els.messageInput.value = "";
  autosize(els.messageInput);

  const topic = getActiveTopic(state.activeProject);
  const now = Date.now();

  topic.messages.push({ role:"user", content:text, ts: now });
  persist();
  renderAll();

  const typingTs = Date.now();
  topic.messages.push({ role:"assistant", content:"Analyzing your request...", ts: typingTs });
  persist();
  renderAll();

  els.sendBtn.disabled = true;
  els.sendBtn.innerHTML = '<span class="loading-spinner"></span><span class="send-text">Sending</span>';

  try{
    const payload = {
      project: state.activeProject,
      topicId: topic.id,
      message: text,
      history: topic.messages
        .filter(m => m.ts !== typingTs)
        .map(m => ({ role: m.role, content: m.content })),
    };

    const res = await fetch(BACKEND_CHAT_URL, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok){
      throw new Error(`Backend ${res.status}: ${await res.text()}`);
    }

    const data = await res.json();
    const answer = data?.answer || "No answer returned.";

    const idx = topic.messages.findIndex(m => m.ts === typingTs);
    if (idx >= 0) topic.messages[idx] = { role:"assistant", content: answer, ts: Date.now() };
    else topic.messages.push({ role:"assistant", content: answer, ts: Date.now() });

  } catch (e){
    const idx = topic.messages.findIndex(m => m.ts === typingTs);
    const fallback =
      "⚠️ **Backend Connection Failed**\n\n" +
      "The backend service is not responding. Make sure your RLM is running and accessible at `POST /api/chat`.\n\n" +
      `**Error:** ${String(e.message || e)}`;

    if (idx >= 0) topic.messages[idx] = { role:"assistant", content: fallback, ts: Date.now() };
    else topic.messages.push({ role:"assistant", content: fallback, ts: Date.now() });
    
    toast('Failed to connect to backend', 'error');
  } finally {
    els.sendBtn.disabled = false;
    els.sendBtn.innerHTML = '<span class="send-icon">➤</span><span class="send-text">Send</span>';
  }

  persist();
  renderAll();
}

function autosize(el){
  el.style.height = "auto";
  el.style.height = Math.min(el.scrollHeight, 150) + "px";
}

function shortDate(s){
  const m = String(s).match(/\d{4}-\d{2}-\d{2}/);
  return m ? m[0] : String(s).slice(0, 10);
}

function persist(){
  try {
    localStorage.setItem(storageKey, JSON.stringify(state));
  } catch (err) {
    toast('Failed to save state to localStorage', 'error');
  }
}

function loadState(){
  try{
    const raw = localStorage.getItem(storageKey);
    if (!raw) return null;
    return JSON.parse(raw);
  } catch {
    return null;
  }
}

function exportState() {
  try {
    const dataStr = JSON.stringify(state, null, 2);
    const blob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `criticalpath-backup-${Date.now()}.json`;
    a.click();
    URL.revokeObjectURL(url);
    toast('Backup exported successfully', 'success');
  } catch (err) {
    toast('Failed to export backup', 'error');
  }
}

function importState(file) {
  const reader = new FileReader();
  reader.onload = (e) => {
    try {
      const imported = JSON.parse(e.target.result);
      if (!imported.files || !imported.projects) {
        toast('Invalid backup file format', 'error');
        return;
      }
      
      if (confirm('Import will replace current state. Continue?')) {
        Object.assign(state, imported);
        persist();
        renderAll();
        toast('State imported successfully', 'success');
      }
    } catch (err) {
      toast('Invalid backup file', 'error');
    }
  };
  reader.readAsText(file);
}

function escapeHtml(str){
  return String(str)
    .replaceAll("&","&amp;")
    .replaceAll("<","&lt;")
    .replaceAll(">","&gt;")
    .replaceAll('"',"&quot;")
    .replaceAll("'","&#039;");
}

function toast(msg, type = 'info') {
  const container = document.getElementById('toastContainer');
  if (!container) return;
  
  const icons = {
    success: '✓',
    error: '✕',
    warning: '⚠',
    info: 'ℹ'
  };
  
  const toastEl = document.createElement('div');
  toastEl.className = `toast toast-${type}`;
  toastEl.innerHTML = `
    <span class="toast-icon">${icons[type] || icons.info}</span>
    <span class="toast-message">${escapeHtml(msg)}</span>
  `;
  
  container.appendChild(toastEl);
  
  setTimeout(() => toastEl.classList.add('show'), 10);
  
  setTimeout(() => {
    toastEl.classList.remove('show');
    setTimeout(() => toastEl.remove(), 300);
  }, 3000);
}