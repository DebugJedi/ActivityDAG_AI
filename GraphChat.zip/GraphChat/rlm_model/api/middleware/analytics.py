"""Analytics Middleware"""
from starlette.middleware.base import BaseHTTPMiddleware
from rlm_model.database.models import Visitor
from rlm_model.database.connection import get_db
import hashlib

class AnalyticsMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request, call_next):
        response = await call_next(request)
        
        if not request.url.path.startswith('/static'):
            try:
                ip_hash = hashlib.sha256(request.client.host.encode()).hexdigest()
                with get_db() as db:
                    visitor = Visitor(ip_hash=ip_hash, page=request.url.path)
                    db.add(visitor)
            except:
                pass
        
        return response
