"""Application Package"""
from rlm_model.core.rlm import RLM

__version__ = "1.0.0"
