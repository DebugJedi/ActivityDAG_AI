import os
from collections import defaultdict
from typing import Any
from dotenv import load_dotenv
from google import genai
from google.genai import types

from rlm_model.client.base_lm import BaseLM
from rlm_model.core.types import ModelUsageSummary, UsageSummary


load_dotenv()

DEFAULT_GEMINI_API_KEY =  os.getenv("gemini_key")


class GeminiClient(BaseLM):
    """
    LM Client for running models with the Google Gemini API.
    Uses the official google-genai SDK.
    """

    def __init__(
            self,
            api_key: str | None = None,
            model_name: str | None = "gemini-2.5-flash",
            **kwargs,
            ):

            super().__init__(model_name, **kwargs)

            if api_key is None:
                  api_key=DEFAULT_GEMINI_API_KEY

            if api_key is None:
                  raise ValueError("Gemini API Key is required. set the api key in env var!")
            
            self.client = genai.Client(api_key=api_key)
            self.model_name = model_name

            # Per-model usage tracking
            self.model_call_count:dict[str, Any]=defaultdict(int)
            self.model_input_tokens:dict[str, Any]=defaultdict(int)
            self.model_output_tokens:dict[str, Any]=defaultdict(int)
            self.model_total_tokens:dict[str, Any]=defaultdict(int)


            self.last_prompt_tokens=0
            self.last_completion_tokens=0

    def completion(
                self, 
                prompt: str | list[dict[str, Any]],
                model: str | None=None
        )-> str:
          
        contents, system_instruction = self._prepare_contents(prompt)
        model = model or self.model_name

        if not model:
           raise ValueError("Model is required for Gemini client!")
        config = None
        if system_instruction:
           config=types.GenerateContentConfig(system_instruction=system_instruction)
        response=self.client.models.generate_content(
             model=model,
             contents=contents,
             config=config
        )
        self._track_cost(response,model)
        return response.text
    
    async def acompletion(
            self, 
            prompt:str | list[dict[str, Any]],
            model: str | None=None)-> str:
        contents, system_instruction=self._prepare_contents(prompt)

        model=model or self.model_name
        if not model:
            raise ValueError("Model is required for Gemini cilent!")
        
        config = None
        if system_instruction:
            config=types.GenerateContentConfig(system_instruction=system_instruction)

        response=await self.client.aio.models.generate_content(
            model=model,
            contents=contents,
            config=config,
        )

        self._track_cost(response, model)
        return response.text
        
    def _prepare_contents(
            self, prompt: str | list[dict[str, Any]]
    )-> tuple[list[types.Content] | str, str |None]:
        """Prepare contents and extract system instruction for Gemini API."""

        system_instruction=None
        
        if isinstance(prompt, str):
            return prompt, None

        if isinstance(prompt, list) and all(isinstance(item, dict) for item in prompt):
            contents=[]
            for msg in prompt:
                role=msg.get("role")
                content=msg.get("content", "")

                if role=='system':
                    system_instruction=content
                elif role=="user":
                    contents.append(types.Content(role='user', parts=[types.Part(text= content)]))
                elif role=="assistant":
                    contents.append(types.Content(role='model', parts=[types.Part(text=content)]))    
                else:
                    contents.append(types.Content(role='user', parts=[types.Part(text=content)]))
            return contents, system_instruction
        raise ValueError(f"Invalid prompt type: {type(prompt)}")
    
    def _track_cost(self, response: types.GenerateContentResponse, model: str):
        self.model_call_counts[model]+=1

        usage = response.usage_metadata
        if usage:
            input_tokens=usage.prompt_token_count or 0 
            output_tokens=usage.candidates_token_count or 0

            self.model_input_tokens[model] +=input_tokens
            self.model_output_tokens[model]+=output_tokens
            self.model_total_tokens[model]+= input_tokens + output_tokens

            self.last_prompt_tokens= input_tokens
            self.last_completion_tokens=output_tokens

        else:
          self.last_prompt_tokens=0
          self.last_completion_tokens=0


    def get_usage_summary(self)->UsageSummary:
        model_summaries={}
        for model in self.model_call_count:
            model_summaries[model] = ModelUsageSummary(
                total_calls=self.model_call_count[model],
                total_input_tokens=self.model_input_tokens[model],
                total_output_tokens=self.model_output_tokens[model],
            )
        return ModelUsageSummary(
            total_calls=1,
            total_input_tokens=self.last_prompt_tokens,
            total_output_tokens=self.last_completion_tokens,
        )
    
    