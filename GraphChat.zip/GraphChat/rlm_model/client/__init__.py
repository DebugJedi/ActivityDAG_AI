from typing import Any
from dotenv import load_dotenv
from typing import get_args
from rlm_model.client.base_lm import BaseLM
from rlm_model.core.types import ClientBackend



def get_client(
        backend: ClientBackend,
        backend_kwargs: dict[str, Any])-> BaseLM:
    """
    Routes a specific backend and the args (as a dict) to the appropriate client if supported.
    Currently supported backends: ['OpenAI']
    """

    if backend == "openai":
        from rlm_model.client.openai import OpenAIClient

        return OpenAIClient(**backend_kwargs)
    
    elif backend == "vllm":
        from rlm_model.client.openai import OpenAIClient

        assert "base_url" in backend_kwargs, (
            "base_url is required to be set to local vLLM server address for vLLM"
        )
        return OpenAIClient(**backend_kwargs)
    
    elif backend == "anthropic":
        from rlm_model.client.anthropic import AnthropicClient

        return AnthropicClient(**backend_kwargs)
    
    elif backend == 'gemini':
        from rlm_model.client.gemini import GeminiClient
        return GeminiClient(**backend_kwargs)
    
    elif backend=='azure_openai':
        from rlm_model.client.azure_openai import AzureOpenAIClient
        return AzureOpenAIClient(**backend_kwargs)
    
    else:
        raise ValueError(
            f"Unknown backend: {backend}. Supported backends: {list(get_args(ClientBackend))}"
        )