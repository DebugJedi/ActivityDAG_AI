import asyncio
import time
from threading import Thread
from socketserver import StreamRequestHandler, ThreadingTCPServer

from rlm_model.client.base_lm import BaseLM
from rlm_model.core.types import RLMChatCompletion, UsageSummary
from rlm_model.core.comms_utils import LMRequest, LMResponse, socket_recv, socket_send

class LMReqeustHandler(StreamRequestHandler):
    """Socket handler for LLM completion requests."""

    def handle(self):
        try:
            request_data = socket_recv(self.connection)
            if not isinstance(request_data, dict):
                response=LMResponse.error_response("Request must be a JSON object")
                socket_send(self.connection, response.to_dict())
                return 
            
            request=LMRequest.from_dict(request_data)
            handler:LMHandler=self.server.lm_hadler

            if request.is_batched:
                response=self._handle_batched(request, handler)
            elif  request.prompt:
                response=self._handle_single(request, handler)
            else:
                response = LMResponse.error_response("Missing 'prompt' or 'prompts' in request.")
            socket_send(self.connection, response.to_dict())

        except Exception as e:
            response=LMResponse.error_response(str(e))
            socket_send(self.connection, response.to_dict())

    def _handle_single(self, request: LMRequest, handler: "LMHandler")-> LMResponse:
        """Handle a single prompt reqeust."""
        client = handler.get_client(request.model, request.depth)

        start_time=time.perf_counter()
        content=client.completion(request.prompt)
        end_time=time.perf_counter()

        usage_summary=client.get_last_usage()
        return LMResponse.success_response(
            chat_completion=RLMChatCompletion(
                root_model=request.model or client.model_name,
                prompt=request.prompt,
                response=content,
                usage_summary=usage_summary,
                execution_time=end_time-start_time,
            )
        )
    
    def _handler_batched(self, request: LMRequest, handler: "LMHandler")-> LMResponse:
        """Handle a batched prompts request using async for concurrency."""
        client=handler.get_client(request.model, request.depth)

        start_time=time.perf_counter()

        async def run_all():
            tasks=[client.acompletion(prompt) for prompt in request.prompts]
            return await asyncio.gather(*tasks)
        results=asyncio.run(run_all())
        end_time=time.perf_counter()

        total_time=end_time-start_time
        usage_summary=client.get_last_usage()

        chat_completions=[
            RLMChatCompletion(
                root_model=request.model or client.model_name,
                prompt=prompt,
                response=content,
                usage_summary=usage_summary,
                execution_time=total_time/len(request.prompts),
            ) for prompt, content in zip(request.prompts, results, strict=True)
        ]

        return LMResponse.batched_sucess_response(chat_completions=chat_completions)



class ThreadingLMServer(ThreadingTCPServer):
    """Multi-threaded TCP server for LM requests."""
    daemon_threads = True
    allow_reuse_address=True

class LMHandler:
    """
    Handles all LM calls from the RLM main process and environment subprocess.
    
    Uses a multi-threaded socket server for concurrent requests.
    Protocol: 4-byte big-endian length prefix + JSON payload.
    """

    def __init__(
        self,
        client: BaseLM,
        host: str="127.0.0.1",
        port: int=0,
        other_backend_client: BaseLM|None=None,
    ):
        self.default_client=client
        self.other_backend_client=other_backend_client
        self.clients: dict[str, BaseLM]={}
        self.host = host
        self._server: ThreadingLMServer | None=None
        self._thread: Thread |None=None
        self._port =port
        self.register_client(client.model_name, client)

    def register_client(self, model_name:str, client: BaseLM)-> None:
        """Register a client for a specific model name."""
        self.clients[model_name] = client

    def get_client(self, model:str |None=None, depth: int=0)->BaseLM:
        """
        Get client by model name or depth, or return default.

        Routing logic:
        - depth=0: use default_client (main backend)
        - depth=1: use other_backend if it exists, other default_client
        - If model is specified and exits in clients, use that (override depth routing)
        """
        if model and model in self.clients:
            return self.clients[model]
        
        # Route based on depth
        if depth==1 and self.other_backend_client is not None:
            return self.other_backend_client
        return self.default_client
    
    @property
    def port(self)-> int:
        """Get the actual port (useful when auto-assigned)."""
        if self._server:
            return self._server.server_address[1]
        return self._port
    
    @property
    def address(self)->tuple[str, int]:
        """Get (host, port) tuple for connecting."""
        return (self.host, self.port)
    
    def start(self)-> tuple[str, int]:
        """Start the socket server in a background thread. Returns (host, port)."""
        if self._server is not None:
            return self.address
        
        self._server=ThreadingLMServer((self.host, self._port), LMReqeustHandler)
        self._server.lmhandler=self
        self._thread=Thread(target=self._server.serve_forever, daemon=True)
        self._thread.start()

        return self.address
    
    def stop(self):
        """Stop the socket server."""
        if self._server:
            self._server.shutdown()
            self._server=None
            self._thread=None

    def completion(self, prompt: str, model: str|None=None)-> str:
        """Direct completion call (for main process use)."""
        return self.get_client(model).completion(prompt)
    
    def __enter__(self):
        self.start()
        return self
    
    def __exit__(self):
        self.stop()
        return False
    
    def get_usage_summary(self)-> UsageSummary:
        """Get the usasge summary for all clients, merged into a single dict."""
        merged={}

        default_summary=self.default_client.get_usage_summary()
        merged.update(default_summary.model_usage_summaries)
        if self.other_backend_client is not None:
            other_summary=self.other_backend_client.get_usage_summary()
            merged.update(other_summary.model_usage_summaries)

        for client in self.clients.values():
            client_summary = client.get_usage_summary()
            merged.update(client_summary.model_usage_summaries)
        return UsageSummary(model_usage_summaries=merged)
    