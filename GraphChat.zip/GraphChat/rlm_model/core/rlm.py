import time
from contextlib import contextmanager
from typing import Any

from rlm_model.client import BaseLM, get_client
from rlm_model.core.lm_handler import LMHandler
from rlm_model.core.types import (
    ClientBackend,
    CodeBlock,
    EnvironmentType,
    REPLResult, 
    RLMChatCompletion,
    RLMIteration,
    RLMMetadata
)

from rlm_model.environments import BaseEnv, SupportsPersistence, get_environment
from rlm_model.logger import RLMLogger, VerbosePrinter
from rlm_model.utils.parsing import (
    find_code_blocks,
    find_final_answer,
    format_iteration,
)
from rlm_model.utils.prompts import (
    RLM_SYSTEM_PROMPT,
    QueryMetdata,
    build_rlm_system_prompt,
    build_user_prompt,
)
from rlm_model.utils.rlm_utils import filter_sensitive_keys


class RLM:
    
    def __init__(
        self,
        backend: ClientBackend="openai",
        backend_kwargs: dict[str, Any] |None = None,
        environment: EnvironmentType="local",
        environment_kwargs: dict[str, Any]|None=None,
        depth:int=0,
        max_depth: int=1,
        max_iterations: int=15,
        custom_system_prompt: str|None=None,
        other_backends: list[ClientBackend]|None=None,
        other_backend_kwargs: list[dict[str, Any]]|None=None,
        logger: RLMLogger|None=None,
        verbose:bool=False,
        persistent: bool=True,
        ):
        """
        Args:
        
            backend: The backend to use for the RLM.
            backend_kwargs: The key arguments to pass to the backend.
            environment: The environment to use for the RLM.
            environment_kwargs: The key argument to pass to the environment.
            depth: The current depth of the RLM (0-indexed).
            max_depth: The maximum depth of the RLM. Currently, only depth 1 is supported.
            max_iterations: The maximum number of iterations of the RLM.
            custom_system_prompt: The custom system prompt to use for the RLM.
            other_backends: A list of other clients that the environment can use.
            logger: logger to use for the RLM.
            verbose: Whether to print verbose output in rich to console.
            Persistent: If True, reuse the environment across completion() call for mulit-turn conversations.
        """

        self.backend = backend
        self.backend_kwargs = backend_kwargs
        self.environment_type = environment
        self.environment_kwargs  = (
                environment_kwargs.copy() if environment_kwargs is not None else {}
        )

        if other_backends is not None:
            if len(other_backends) !=1:
                raise ValueError(
                        "We currently only support one additional backend for the recursive sub-calls!"     
                )
        
        self.other_backends = other_backends
        self.other_backend_kwargs = other_backend_kwargs
        self.depth = depth
        self.max_depth = max_depth
        self.max_iterations = max_iterations
        self.system_prompt = custom_system_prompt if custom_system_prompt else RLM_SYSTEM_PROMPT
        self.logger = logger
        self.verbose = VerbosePrinter(enabled=verbose)

        self.persistent = persistent
        self._persistent_env: SupportsPersistence | None=None

        if self.persistent:
                self._validate_persistent_environment_support()
        
        if self.logger or verbose:
            metadata = RLMMetadata(
                root_model=backend_kwargs.get("model_name", "unknown") if backend_kwargs else "unknown",
                max_depth=max_depth,
                max_iterations=max_iterations,
                backend=backend,
                backend_kwargs=filter_sensitive_keys(backend_kwargs) if backend_kwargs else {},
                environment_type=environment,
                environment_kwargs=filter_sensitive_keys(environment_kwargs) if environment_kwargs else {},
                other_backends=other_backends,
            )
            if self.logger:
                self.logger.log_metadata(metadata)
            self.verbose.print_metadata(metadata)
    
    @contextmanager
    def _spawn_completion_context(self,prompt: str|dict[str, Any]):
        """
        Spawn an LM handler and environment for a single completion call.

        When persistent = True, the environment is reused across calls.
        When persistent = False , creates fresh environment each call. 
        """

        client: BaseLM = get_client(self.backend, self.backend_kwargs)

        other_backend_client: BaseLM | None=None
        if self.other_backends and self.other_backend_kwargs:
            other_backend_client = get_client(self.other_backends[0], self.other_backend_kwargs[0])
        
        lm_handler = LMHandler(client, other_backend_client=other_backend_client)

        if self.other_backends and self.other_backend_kwargs:
            for backend, kwargs in zip(self.other_backends, self.other_backend_kwargs, strict=True):
                other_client: BaseLM = get_client(backend, other_client)
                lm_handler.register_client(other_client.model_name, other_client)
        lm_handler.start()

        if self.persistent and self._persistent_env is not None:
            environment = self._persistent_env
            if not self._env_supports_persistence(environment):
                raise RuntimeError(
                    f"Persistent environment of type '{type(environment).__name__}' does not "
                    f"implement required methods (update_handler_address, add_context, get_context_count). "
                    f"This should have been caught at initalization."
                    
                )
        
        else:
            env_kwargs = self.environment_kwargs.copy()
            env_kwargs["lm_handler_address"] = (lm_handler.host, lm_handler.port)
            env_kwargs["context_payload"]=prompt
            env_kwargs["depth"] = self.depth +1 
            environment: BaseEnv = get_environment(self.environment_type, env_kwargs)

            if self.persistent:
                self._persistent_env = environment

        try:
            yield lm_handler, environment
        finally:
            lm_handler.stop()
            if not self.persistent and hasattr(environment, "cleanup"):
                environment.cleanup()

    def _setup_prompt(self, prompt: str|dict[str, Any])-> list[dict[str, Any]]:
        """
        Setup the system prompt for the RLM. Also include metadat about the prompt an build
        up the initial message history
        """
        metadata = QueryMetdata(prompt)
        message_history = build_rlm_system_prompt(
             system_prompt=self.system_prompt, query_metadata=metadata
        )

        return message_history
    
    def completion(
        self, prompt: str|dict[str, Any], root_prompt: str|None=None
    )-> RLMChatCompletion:
        """
        Recursive Language Model completion call. This is the main entry point for querying an RLM, and 
        can replace a regular LM completion call.

        Args:
            Prompt: A single string or dictionary of message to pass as context to the model.
            root_prompt: We allow the RLM's root LM to see a (small) prompt that the user specifies.
        Returns:
            A final answer as a string.
        """
        time_start = time.perf_counter()

        if self.depth >= self.max_depth:
            return self._fallback_answer(prompt)
        
        with self._spawn_completion_context(prompt) as (lm_handler, environment):
            message_history = self._setup_prompt(prompt)

            for i in range(self.max_iterations):
                context_count = (
                    environment.get_context_count()
                    if isinstance(environment, SupportsPersistence)
                    else 1
                )
                history_count = (
                    environment.get_history_count()
                    if isinstance(environment, SupportsPersistence)
                    else 0
                )
                current_prompt = message_history + [
                    build_user_prompt(root_prompt, i, context_count, history_count)
                ]

                iteration: RLMIteration = self._completion_turn(
                    prompt=current_prompt,
                    lm_handler=lm_handler,
                    environment=environment,
                )

                final_answer = find_final_answer(iteration.response, environment=environment)
                iteration.final_answer = final_answer

                if self.logger:
                     self.logger.log(iteration)
                
                self.verbose.print_iteration(iteration, i+1)

                if final_answer is not None:
                    time_end = time.perf_counter()
                    usage = lm_handler.get_usage_summary()
                    self.verbose.print_final_answer(final_answer)
                    self.verbose.print_summary(i+1, time_end-time_start, usage.to_dict())

                    if self.persistent and isinstance(environment, SupportsPersistence):
                         environment.add_history(message_history)

                    return RLMChatCompletion(
                        root_model = self.backend_kwargs.get("model_name", "unknown")
                        if self.backend_kwargs
                        else "unknown",
                        prompt=prompt,
                        response= final_answer,
                        usage_summary = usage,
                        execution_time=time_end-time_start,
                    )
                
                new_messages = format_iteration(iteration)
                message_history.extend(new_messages)
            
            time_end = time.perf_counter()
            final_answer = self._default_answer(message_history, lm_handler)
            usage = lm_handler.get_usage_summary()
            self.verbose.print_final_answer(final_answer)
            self.verbose.print_summary(self.max_iterations, time_end-time_start, usage.to_dict())

            if self.persistent and isinstance(environment, SupportsPersistence):
                 environment.add_history(message_history)

            return RLMChatCompletion(
                 root_model = self.backend_kwargs.get("model_name", "unknown")
                 if self.backend_kwargs else "unknown",
                 prompt = prompt,
                 response=final_answer,
                 usage_summary=usage,
                 execution_time=time_end-time_start
            )
                

        
    def _completion_turn(
        self,
        prompt: str|dict[str, Any],
        lm_handler: LMHandler,
        environment: BaseEnv,
    )-> RLMIteration:
        """
        Perfom a single iteration of the RLM, including prompting the model and code execution + tool execution.
        """
        iter_start = time.perf_counter()
        response = lm_handler.completion(prompt)
        code_block_strs = find_code_blocks(response)
        code_blocks = []

        for code_block_str in code_block_strs:
            code_result: REPLResult = environment.execute_code(code_block_str)
            code_blocks.append(CodeBlock(code=code_block_str, result=code_result))
        
        iteration_time = time.perf_counter() - iter_start

        return RLMIteration(
            prompt=prompt,
            response=response,
            code_blocks=code_blocks,
            iteration_time = iteration_time
        )
    
    def _default_answer(self, message_history: list[dict[str, Any]], lm_handler: LMHandler) -> str:
        """
        Default behavior if RLM runs out of iterations and does find a final answer.
        It will take the message history, and try to generate a final answer from it.
        """

        current_prompt = message_history + [
             {
                  "role": "assistant",
                  "content": "Please provide a final answer to the user's question based on the information provided.",
             }
        ]
        response = lm_handler.completion(current_prompt)

        if self.logger:
            self.logger.log(
                RLMIteration(
                    prompt=current_prompt,
                    response=response,
                    final_answer=response,
                    code_blocks=[],
                )
            )
        return response

                
    def _fallback_answer(self, message: str|dict[str, Any])-> str:
        """
        Fallback behavior if the RLM is actually at max depth, and should be treated as an LM.
        """              
        client: BaseLM = get_client(self.backend, self.backend_kwargs)
        response = client.completion(message)
        return response
            
            
                  

    def _validate_persistent_environment_support(self)-> None:
          """
          Validate that the configured environment type support persistent mode.
          Persistent mode require environment to implement:
          - update_handler_address(address): Update LM handler address between calls
          - add_context(payload, index): Add new context for multi-turn conversations
          - get_context_count(): Return the number of loaded contexts
          
          Raises:
            Value Error: If the environment type does not support peristent mode.
          """

          persistent_supported_environment = {"local"}

          if self.environment_type not in persistent_supported_environment:
                raise ValueError(
                      f"persistent=True is not supported for the environment_type '{self.environment_type}'."
                      f"Supported environments: {sorted(persistent_supported_environment)}"
                )
          
    @staticmethod
    def _env_supports_persistence(env:BaseEnv)->bool:
          return isinstance(env, SupportsPersistence)
    
    def close(self)->None:
          "Clean up persistence environment."
          if self._persistent_env is not None:
                if hasattr(self._persistent_env, "cleanup"):
                    self._persistent_env.cleanup()
                self._persistent_env = None
    
    def __enter__(self)->"RLM":
          return self
    
    def __exit__(self, exc_type, exc_val, exc_tb)->bool:
          self.close()
          return False