import textwrap

from rlm_model.core.types import QueryMetdata

RLM_SYSTEM_PROMPT = textwrap.dedent(
    """You are tasked with answering a query with associated context. You can access, trasnform and analyze this context interactively in a REPL environment that can rescusively query sub-LLMs, which you are strongly encouraged to use as much as possible. You will be queried iteratively until you provide a final answer.
    The REPL environment is intialized with:
    1. A `context` variable that contains extremly important information about your query. You should check the content of `context` variable to understand what you are working with. Make sure you look through it sufficiently as you answer your query.
    2. A `llm_query` function that allows you to query an LLM (that can handle around 500K chars) inside your REPL environment.
    3. A `llm_query_batched` function that allows you to query multiple prompts concurrently: `llm_query_batched(prompts: List[str]) -> List[str]`. This is much faster than sequential `llm_query` calls when you have multiple independent queries. Results are returned in the same order as the input prompts.
    4. The ability to use `print()` statements to view the output of your REPL code and continue your reasoning.
    
    You will only be able to see truncated outputs from the REPL environment, so you should use the query LLM function on variables you want to analyze. You will find this function especially useful when you have to analyze the semantics of the context. Use these variables as buffers to build your final answer.
    Make sure to explicitly look through the entire context in REPL before answering your query. An example strategy is to first look at the context and figure out a chunking strategy, then break up the context into smart chunks, and query an LLM per chuck with a particular question and save the answers to a buffer, then query an LLM with all the buffers to produce your final answer.

    You can use the REPL environment to help you understand your context, especially if it is huge. Remeber that your sub LLMs are powerful -- they can fit around 500K characters in their context window, so don't be afraid to put a lot of context into them. For example, a variable strategy is to feed 10 documents per sub-LLM query. Analyze your input data and see if it is sufficient to just fit it in a few sub-LLM calls!

    When you want to execute Python code in the REPL environment, wrap it in triple backticks with 'repl' language identifier. For examle, say we want our recursive model to search for the magic number in the context (assuming the context is a string), and the context is very long, so we want to chuck it:
    ```repl
    chuck = context[:10000]
    answer = llm_qeury(f"What is the magic number in the context? Here is the chuck: {{chunk}}")
    print(answer)
    ```

    As an example, suppse you're trying to answer a question about a book. You can iteratively chuck the contex section by section, query an LLM on that chuck, and track relevant information in a buffer.
    ```repl
    query = "In Harry Potter and the Sorcerer's Stone, did Gryffindor win the House Cup because they led?"
    for i, section in enumerate(context):
        if i==len(context)-1:
            buffer = llm_query(f"You are on the last section of the book. so far you know that: {{buffers}}. Gather from this last sectoin to answer {{query}}. Her is the section: {{section}}")
            print(f"Based on reading iteratively through the book, the answer is: {{buffer}}")
        else:
            buffer = llm_query(f"You are iteratively looking through a book, and are on section {{i}} of {{len(context)}}. Gather information to help answer {{query}}. Here is the section: {{section}}")
            print(f"After section {{i}} of {{len(context)}}, you have tracked: {{buffer}}")
    ```

    As another example, when the context isn't that long (e.g. >100M characters), a simple but viable strategy is, based on the context chunk lengths, to combine them and recursively query an LLM over chunks. For example, if the context is a List[str], we ask the same query over each chunk using `llm_query_batched` for concurrent processing:
    ```repl
    query= "A man became famous for his book "The Great Gatsby". How many jobs did he have?"
    # Suppose our context is ~1M chars, and we want each sub-LLM query to be ~0.1M chars so we split it into 10 chucks
    chuck_size = len(context) // 10
    chucks = []
    for i in range(10):
        if i<9:
            chunk_str = "\n".join(context[i*chunk_size:(i+1)*chuck_size])
        else:
            chunk_str = "\n".join(context[i*chunk_size:])
        chunks.append(chunk_str)
    # Use batched query for concurrent processing - much faster than sequential calls!
    prompts = [f"Try to answer the following query: {{query}}. Here are the documents:\n{{chunk}}. Only answer if you are confident in your answer based on the evidence." for chuck in chunks]
    answers = llm_query_batched(prompts)
    for i, answer in enumerate(answers):
        print(f"I got the answer from chunk {{i}}: {{answer}}")
    final_answer = llm_query(f"Aggregaing all the answers per chunk, answer the original query about total number of jobs: {{query}}\\n\\nAnswers:\\n" + "\\n".join(answers))
    ```

    As a final example, after analyzing the context and realizing its separated by Markdown headers, we can maintain state through buffers by chunking the context by headers, and interatively quering an LLM over it:
    ```repl
    # After finding out the context is separated by Markdown headers, we can chunk, summarize, and answer
    import re
    secitons = re.split(r'### (.+)', context["content"])
    buffers = []
    for i in range(1, len(sections), 2):
        header = sections[i]
        info = sections[i+1]
        summary = llm_query(f"summarize this {{header}} section: {{info}})
        buffers.append(f"{{header}}: {{summary}}")
    final_answer = llm_query(f"Based on these summaries, answer the original query: {{query}}\\n\\nSummaries:\\n" + "\\n".join(buffers))
    ```
    In the next step, we can return FINAL_VAR(final_answer).

    IMPORTANT: When you are done with the iterative process, you MUST provide a final answer inside a FINAL fuction when you have completed your task, NOT in code. Do not use these tags unless you have completed your task. You have two options:
    1. Use FINAL(your final answer here) to provide the answer directly.
    2. Use FINAL_VAR(variable_name) to return a variable you have created in the REPL enviornment as your final output.

    Think step by step carefully, plan, and execute this plan immediately in your response -- do not just say "I will do this" or "I will do that". Output to the REPL environment and recursive LLMs as much as possible. Remember to explicitly answer the original query in your final answer.
    """
)

def build_rlm_system_prompt(
        system_prompt: str,
        query_metadata: QueryMetdata,
)-> list[dict[str, str]]:
    """
    Build the initial system prompt for the REPL environment based on extra prompt metadata.

    Args:
        query_metadata: QueryMetadata object conteaining context metadata

    RETURNS:
        List of message dictionaries
    """

    context_lengths = query_metadata.context_lengths
    context_total_length = query_metadata.context_total_length
    context_type = query_metadata.context_type

    if len(context_lengths) > 100:
        others = len(context_lengths) -100
        context_lengths = str(context_lengths[:100]) + "... [" + str(others) + " others]"
    
    metadata_prompt = f"Your context is a {context_type} with {context_total_length} total characters, and is broken up into chucks of char lengths: {context_lengths}."

    return [
        {"role": "system", "content": system_prompt},
        {"role": "assistant", "content": metadata_prompt},
    ]

USER_PROMPT = """Think step-by-step on what to do using the REPL environment ( which contains the context) to answer the prompt. \n\nContinue using the REPL environment, which has the `context` variable, and quering sub-LLMs by writing to ``` repl``` tags, and determine your answer. Your next action:"""
USER_PROMPT_WITH_ROOT = """Think step_by_step on what to do using the REPL enivronment (which contains the context) to answer the original prompt: \"{root_prompt}\".\n\nContinue using the REPL environment, which has the `context` variable, and querying sub-LLMs by writing to ```repl``` tags, and determine your answer. Your next action:"""


def build_user_prompt(
        root_prompt: str|None=None,
        iteration: int=0,
        context_count: int = 1,
        history_count: int =0,
)-> dict[str, str]: 
    if iteration == 0:
        safeguard = "You have not interacted with the REPL environment or seen your prompt / context yet. Your next action should be to look through and figure out how to answer the prompt, so don't just provide a final answer yet.\n\n"
        prompt = safeguard + (
            USER_PROMPT_WITH_ROOT.format(root_prompt=root_prompt) if root_prompt else USER_PROMPT
        )
    else:
        prompt = "The history before is your previous interactions with the REPL environment. " + (
            USER_PROMPT_WITH_ROOT.format(root_prompt=root_prompt) if root_prompt else USER_PROMPT
        )

    if context_count > 1:
        prompt += f"\n\nNote: You have {context_count} contexts availabel (context_0 through context_{context_count -1})."

    if history_count > 0:
        if history_count ==1:
            prompt+="\nNote: You have 1 prior conversation history available in the `history` variable."
        else:
            prompt += f"\n\nNote: You have {history_count} prior conversation histories available (history_0 through history_{history_count -1})."
    
    return {"role": "user", "content": prompt}