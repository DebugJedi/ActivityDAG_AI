from typing import Any, Literal
from rlm_model.environments.base_env import BaseEnv, SupportsPersistence
from rlm_model.environments.local_repl import LocalREPL

__all__ = ["BaseEnv", "LocalREPL", "Support Persistence", "get_environment"]

def get_environment(
        environment: Literal["local", "modal", "docker"],
        environment_kwargs: dict[str, Any],
)->BaseEnv:
    """
    Routes a specific environment and the args (as a dict) to the appropriate environment if supported.
    Currently supported environments: ['local', 'modal', 'docker']
    """
    if environment=='local':
        return LocalREPL(**environment_kwargs)

    else:
        raise ValueError(
            f"Unknown environment: {environment}. Supported: ['local', 'docker']"
        )