import os 
import sys
from rlm_model.core.rlm import RLM
from rlm_graph.config import DEFAULT_BACKEND, DEFAULT_MODEL, DEFAULT_MAX_ITERATIONS
from dotenv import load_dotenv
load_dotenv()

sys.path.append(os.getcwd())

BACKEND = DEFAULT_BACKEND
MODEL = DEFAULT_MODEL
MAX_ITERATIONS = DEFAULT_MAX_ITERATIONS

# BASE_DIR = Path(__file__).resolve().parent

SYSTEM_PROMPT_PATH = "rlm_graph/prompts/system_prompt.md"

with open(SYSTEM_PROMPT_PATH, 'r') as f:
    SYSTEM_PROMPT = f.read()

def build_tagged_context(query: str)-> str:
    """Build the context explicit XLM tags to anchor the query and memory."""

    return f"""<query>
{query}
</query>

<memory>
Empty - start by exploring the graph to find relevant nodes.
</memory>

<graph_context>
Use the tools above to explore the graph and find information relevan to the query.
Start by searching for documents or entities related to the key terms in the query.
</graph_context>
"""

def main(USER_QUERY):

    if not os.getenv("openai_key"):
        print("Error: OPENAI_API_KEY not set.")
        return 
    
    user_query = USER_QUERY
    
    tagged_context = build_tagged_context(user_query)

    print(f"Query: {user_query}")
    print("Initializing RLM Agent....")

    setup_code = """
from rlm_graph.tools import node_find, node_get, neighbors, subgraph, answer, recurse, semantic_search
print("Graph Tools Loaded (including semantic_search).")
"""

    rlm = RLM(
        backend=BACKEND,
        backend_kwargs={"model_name": MODEL},
        environment="local",
        environment_kwargs={"setup_code": setup_code},
        custom_system_prompt=SYSTEM_PROMPT,
        verbose=True,
        max_iterations=MAX_ITERATIONS
    )
    result = rlm.completion(tagged_context, root_prompt=user_query)
    
    print("#"*34,"Printing FinalResponse", "#"*34)
    print(result.response)


if __name__ =="__main__":
    main()
    