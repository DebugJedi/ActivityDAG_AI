import argparse
import sys
import os
from rlm_graph.graphify.builder import GraphBuilder
from rlm_graph.graph_env.vector_store import get_vector_store


def main():
    parser=argparse.ArgumentParser(description="Infest documents into RLM-Graph.")
    parser.add_argument("--dir", type=str, required=True, help="Directory containing markdown files.")
    parser.add_argument("--db", type=str, help="Database path (optional).")
    parser.add_argument("--force-embeddings", action="store_true", help="Force recomputation of embeddings.")

    args = parser.parse_args()

    if not os.path.isdir(args.dir):
        print(f"Error: {args.dir} is not a directory.")
        sys.exit(1)

    builder = GraphBuilder(db_path=args.db)
    builder.process_director(args.dir)

    print("Refreshing Vector Store....")
    vector_store = get_vector_store(builder.adapter)
    vector_store.initialized(force_recompute=args.force_embeddings)

    print("Ingestion complete.")

if __name__ == "__main__":
    main()