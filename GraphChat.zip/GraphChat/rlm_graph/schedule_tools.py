from pathlib import Path
from rlm_graph.schedule_graph.p6_loader import load_p6
from schedule_graph.schedule_graph import ScheduleGraph

_DATA =None
_ACTIVE_PROJ_ID = None
_GRAPH = None

def init_data(folder: str="./"):
    global _DATA
    _DATA = load_p6(folder)
    return True

def list_projects():
    global _DATA
    if _DATA is None:
        init_data("./")
    p = _DATA.project.dropna(subset=["proj_id"])

    out = (
        p[["proj_id", "proj_short_name"]]
        .drop_duplicates()
        .sort_values("proj_short_name")
        .to_dict(orient="records")
    )
    return out

def set_project(proj_id: str):
    global _DATA, _ACTIVE_PROJ_ID, _GRAPH
    if _DATA is None:
        init_data("./")

    _ACTIVE_PROJ_ID = str(proj_id)

    t = _DATA.task[_DATA.task["proj_id"].astype(str)== _ACTIVE_PROJ_ID]
    r = _DATA.taskpred[_DATA.taskpred["proj_id"].astype(str)==_ACTIVE_PROJ_ID] if "proj_id" in _DATA.taskpred.columns else _DATA.taskpred

    _GRAPH =ScheduleGraph(t, r)
    return {"project": _ACTIVE_PROJ_ID, "tasks": int(_GRAPH.G.number_of_nodes()), "rels": int(_GRAPH.G.number_of_edges())}

def critical_path():
    if _GRAPH is None:
        return {"error": "No active project. Call set_project(proj_id) first."}
    path, hours = _GRAPH.critical_path_v1(eps=0.0)
    rows =[]
    for tid in path[:200]:
        a = _GRAPH.G.nodes[tid]
        rows.append({
            "task_id": tid,
            "task_code": a.get("task_code"),
            "task_name": a.get("task_name"),
            "duration_hr": a.get("duration_hr"),
            "total_float_hr": a.get("total_float_hr"),
        })

    return {"cirtical_path_hours": hours, "path": rows}

def float_report(threshold_hr: float=40.0):
    if _GRAPH is None:
        return {"error": "No active project. Call set_project(proj_id) first."}
    
    crit = _GRAPH.critical_tasks(eps=0.0)
    near = _GRAPH.near_critical_tasks(threshold_hr=threshold_hr, eps=0.0)
    return {"critical_count": len(crit), "near_cirtical_count": len(near), "threshold_hr": threshold_hr}

def schedule_summary():
    if _GRAPH is None:
        return {"error": "No active project. Call set_project(proj_id) first."}
    
    floats = [float(a.get("total_float_hr", 0.0)) for _, a in _GRAPH.G.nodes(data=True)]
    durs = [float(a.get("duration_hr", 0.0)) for _, a in _GRAPH.G.nodes(data=True)]

    return {
        "tasks": _GRAPH.G.number_of_nodes(),
        "relationships": _GRAPH.G.number_of_edges(),
        "avg_duration_hr": sum(durs)/len(durs) if durs else 0.0,
        "min_float_hr": min(floats) if floats else 0.0,
        "max_float_hr": max(floats) if floats else 0.0,
    }
