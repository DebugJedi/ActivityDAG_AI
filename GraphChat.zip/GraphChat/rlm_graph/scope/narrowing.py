from typing import List, Dict, Any
from .scope_manager import ScopeManager, Scope
from rlm_graph.graph_env.adapters.base import GraphAdapter

class NarrowingOperators:
    """Operators to reduce or manipulate scopes."""

    def __init__(self, manager: ScopeManager):
        self.manager = manager
        self.adapter = manager.adapter

    def by_type(self, scope_id: str, label: str)->Scope:
        """Filter scope to only nodes of a certain labels."""
        scope = self.manager.scope_get(scope_id)
        if not scope: pass

        ids_list = list(scope.node_ids)
        filterd_ids = []

        for nid in ids_list:
            node_data = self.adapter.node_get(nid)
            if node_data and node_data.get('_label') == label:
                filterd_ids.append(nid)
        return self.manager.scope_create(filterd_ids, f"Narrowed {scope_id} by type {label}")

    def by_neighbors(self, scope_id: str, rel_type: str=None, direction: str="Both")-> Scope:
        """Step next to related node - Step_neighbors"""
        scope = self.manager.scope_get(scope_id)
        new_ids = set()

        for nid in scope.node_ids:
            nbrs = self.adapter.neighbors(nid, rel_type, direction)
            for n in nbrs:
                node_id=n.get('id')
                if node_id:
                    new_ids.add(node_id)

        return self.manager.scope_create(list(new_ids), f"Neighbors of {scope_id}")