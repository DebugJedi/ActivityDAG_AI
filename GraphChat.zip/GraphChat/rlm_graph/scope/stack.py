from dataclasses import dataclass, field
from typing import List, Optional
from .scope_manager import Scope

@dataclass
class StackFrame:
    scope_id: str
    intent: str
    depth: int
    data: dict = field(default_factory=dict)

class RecursionStack:
    def __init__(self):
        self.stack = List[StackFrame] = []

    def push(self, scope_id:str, intent: str, data: dict =None):
        depth = len(self.stack)
        frame = StackFrame(scope_id, intent, depth, data or {})
        self.stack.append(frame)
        return frame
    
    def pop(self)->Optional[StackFrame]:
        if not self.stack:
            return None
        return self.stack.pop()
    
    def current_frame(self)->Optional[StackFrame]:
        if not self.stack:
            return None
        return self.stack[-1]
    
    def depth(self)->int:
        return len(self.stack)
    
    def is_empty(self)->bool:
        return len(self.stack)==0