from typing import List, Dict, Any, Optional,Set
import uuid
from dataclasses import dataclass, field
from rlm_graph.graph_env.adapters.base import GraphAdapter

@dataclass
class Scope:
    """
    Represents a subset of the graph (nodes).
    """
    id: str
    description: str
    node_ids: set[str]
    metadata: Dict[str, Any]=field(default_factory=dict)


class ScopeManager:
    """
    Manages creation and retrieval of Scopes.
    """

    def __init__(self, adapter: GraphAdapter):
        self.adapter = adapter
        self.scopes: Dict[str, Scope]={}

    def scope_create(self, node_ids: List[str], description: str="Custom Scope")->Scope:
        """Create a new scope from a list of node IDs."""
        scope_id = str(uuid.uuid4)
        unique_ids = set(node_ids)

        scope = Scope(
            id = scope_id,
            description=description,
            node_ids=unique_ids
        )
        self.scopes[scope_id] = scope
        return scope
    
    def scope_get(self, scope_id: str)-> Optional[Scope]:
        return self.scopes.get(scope_id)
    
    def scope_nodes(self, scope_id: str)-> List[Dict[str, Any]]:
        """Get full node objects for a scope."""
        scope = self.scopes.get(scope_id)
        if not scope:
            return []
        
        results = []
        for nid in scope.node_ids:
            n = self.adapter.node_get(nid)
            if n:
                results.append(n)
        return results
    
    def scope_intersect(self, scope_id_a: str, scope_id_b: str, desc: str=None)->Scope:
        s1 = self.scopes.get(scope_id_a)
        s2 = self.scopes.get(scope_id_b)
        if not s1 or not s2:
            raise ValueError("Scope not found")
        new_ids = s1.node_ids.intersection(s2.node_ids)
        return self.scope_create(list(new_ids), desc or f"Intersection {s1.id} & {s2.id}")