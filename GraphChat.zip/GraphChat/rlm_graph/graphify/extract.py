import re
from typing import List, Dict, Any

def extract_entities(text: str)->List[Dict[str, Any]]:
    """
    Extract entities from text using simple heuristics.
    Returns list of {'name':str, 'type': str,.....}
    """
    entities = []
    seen = set()


    code_matches = re.findall(r'`([^`\n]+)`', text)

    for m in code_matches:
        if len(m) < 2 or len(m)>50: continue
        if m in seen: continue
        entities.append({'name': m, 'type': 'Code'})
        seen.add(m)



    link_matches = re.findall(r'\[([^\]]+)\]\(([^\)]+)\)', text)
    for txt, url in link_matches:
        name = txt.strip()
        if not name or name in seen: 
            continue

        entities.append({'name': name, 'type': 'Reference', 'url': url})
        seen.add(name)


    return entities
