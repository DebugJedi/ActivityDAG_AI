import os
import hashlib
from typing import List
from rlm_graph.graph_env.adapters.kuzu_adapter import KuzuAdapter
from .ingest import IngestedDoc, chunk_text
from .extract import extract_entities
from datetime import datetime

class GraphBuilder:
    def __init__(self, db_path:str=None):
        if db_path is None:
            from rlm_graph.config import get_db_path
            db_path = get_db_path()
        self.adapter = KuzuAdapter(db_path)
    
    def process_director(self, dir_path: str):
        print(f"Processing directory: {dir_path}")
        for root, dirs, files in os.walk(dir_path):
            for file in files:
                if file.endswith('.md'):
                    self.process_file(os.path.join(root, file))
    
    def process_file(self, filepath: str):
        print(f"Ingesting file: {filepath}")
        doc = IngestedDoc(filepath)

        self.adapter.add_node("Doc", {
            "id": doc.doc_id,
            "title": doc.filename,
            "source": filepath,
            "timestamp": datetime.today()
        })

        for sec in doc.sections:
            sec_id = hashlib.md5(f"{doc.doc_id}_{sec['order']}".encode()).hexdigest()
            # heading might be long
            heading_stripped = sec['heading'][:100].replace('"', "'") 
            
            self.adapter.add_node("Section", {
                "id": sec_id,
                "doc_id": doc.doc_id,
                "heading": heading_stripped,
                "section_order": sec['order']
            })
            self.adapter.add_edge(doc.doc_id, "Doc", sec_id, "Section", "HAS_SECTION")
            
            if not sec.get('text'):
                continue

            chunks = chunk_text(sec['text'])
            for chk in chunks:
                chk_id = hashlib.md5(f"{sec_id}_{chk['index']}".encode()).hexdigest()
                text_content = chk['text'].replace('"', "'")
                self.adapter.add_node("Chunk", {
                    "id": chk_id,
                    "section_id": sec_id,
                    "text": text_content,
                    "start_offset": chk['start'],
                    "end_offset": chk['end'],
                })

                self.adapter.add_edge(sec_id, "Section", chk_id, "Chunk", "HAS_CHUNK")


                entities = extract_entities(chk['text'])
                for ent in entities:
                    ent_name = ent['name']
                    ent_type = ent['type']
                    ent_id = hashlib.md5(f"{ent_type}_{ent_name}".lower().encode()).hexdigest()

                    self.adapter.add_node("Entity", {
                        "id": ent_id,
                        "name": ent_name,
                        "type": ent_type,
                        "aliases": []
                    })


                    self.adapter.add_edge(chk_id, "Chunk", ent_id, "Entity", "MENTIONS", {'confidence': 1.0})