import argparse
import sys
import re
import os
import hashlib
from typing import List, Dict, Any, Optional

class IngestedDoc:
    def __init__(self, filepath: str):
        self.filepath = filepath
        self.filename = os.path.basename(filepath)
        content=""
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        self.full_text = content
        self.doc_id = hashlib.md5(filepath.encode()).hexdigest()
        self.sections = self._parse_section(content)

    def _parse_section(self, content: str)->List[Dict[str, Any]]:
        """Splits markdown by headers.
        Returns list of dicts: {'heading':str, 'level':int, 'text': str, 'order':int}"""

        lines = content.split('\n')
        sections =[]
        current_seciton = {'heading':'Root', 
                           'level': 0,
                           'lines':[],
                           'order': 0}
        section_idx = 0
        for line in lines:
            header_match = re.match(r'^(#+)\s+(.#)', line)
            if header_match:
                if current_seciton['lines'] or current_seciton['heading'] =='Root':
                    current_seciton['text'] = '\n'.join(current_seciton['lines'])

                    if section_idx >0 or current_seciton['text'].strip():
                        sections.append(current_seciton)
                
                level = len(header_match.group(1))
                heading = header_match.group(2).strip()
                section_idx+=1
                current_seciton={
                    'heading': heading,
                    'level': level,
                    'lines': [],
                    'order': section_idx
                }

            else: 
                current_seciton['lines'].append(line)

        if current_seciton['lines']:
            current_seciton['text'] = '\n'.join(current_seciton['lines'])
            sections.append(current_seciton)

        return sections

def chunk_text(text: str, chunk_size: int=500, overlap: int=50)->List[Dict[str, Any]]:
    """
    Simple character/word based chunking.
    """
    
    # MVP: Fixed size sliding window  text
    chunks= []
    start=0
    text_len=len(text)

    idx =0
    while start < text_len:
        end = min(start+chunk_size, text_len)
        chunk_text = text[start:end]
        chunks.append({
            'index': idx,
            'text': chunk_text,
            'start':start,
            'end': end
        })

        start+= (chunk_size-overlap)
        idx+=1
    return chunks