import os
from typing import List, Dict, Any, Optional
from rlm_graph.graph_env.adapters.kuzu_adapter import KuzuAdapter
from rlm_graph.scope.scope_manager import ScopeManager, Scope
from rlm_model.core.rlm import RLM

from rlm_graph.config import get_db_path

_DB_PATH = get_db_path()

_ADAPTER = None
_SCOPE_MANAGER = None
_VECTOR_STORE = None

def _get_adapter():
    global _ADAPTER
    if _ADAPTER is None:
        _ADAPTER = KuzuAdapter(_DB_PATH)
    return _ADAPTER

def _get_scope_manager():
    global _SCOPE_MANAGER
    if _SCOPE_MANAGER is None:
        _SCOPE_MANAGER = ScopeManager(_get_adapter())
    return _SCOPE_MANAGER

def _get_vector_store():
    global _VECTOR_STORE
    if _VECTOR_STORE is None:
        from rlm_graph.graph_env.vector_store import VectorStore
        _VECTOR_STORE = VectorStore(_get_adapter())
    return _VECTOR_STORE

import json

def _print_result(res: Any):
    """Helper to print result for REPL capture."""
    try:
        print(json.dumps(res, indent=2, default=str))
    except Exception:
        print(str(res))

def semantic_search(query: str, top_k: int=5)-> List[Dict[str, Any]]:
    """Search for chunks semantically similar to the query."""

    print(f"[TOOL] semantic_search(query='{query[:50]}....', top_k={top_k})")
    vs = _get_vector_store()
    res = vs.search(query, top_k)

    simplified = []
    for r in res:
        simplified.append({
            "id": r.get("id"),
            "text": r.get("text", "")[:200] + "..." if len(r.get("text", "")) > 200 else r.get("text", ""),
            "section_id": r.get("section_id"),
            "score": round(r.get("similarity_score", 0), 3)

        })

    _print_result(simplified)
    return res

def node_find(label: str=None, properties:dict=None, limit: int=10)-> List[Dict[str, Any]]:

    print(f"[TOOL] node_find(label={label}, properties={properties})")
    res = _get_adapter().node_find(label, properties, limit)
    _print_result(res)
    return res

def node_get(node_id: str)-> Optional[Dict[str,Any]]:
    print(f"[TOOL] node_get({node_id})")
    res = _get_adapter().node_get(node_id)
    _print_result(res)
    return res

def neighbors(node_id: str, rel_type: str=None, direction: str="BOTH", limit:int=50)->List[Dict[str, Any]]:
    print(f"[TOOL] neighbors({node_id}, {rel_type}, {direction})")
    res = _get_adapter().neighbors(node_id, rel_type, direction, limit)
    _print_result(res)
    return res

def subgraph(seed_ids: List[str], k_hops: int=1)->Dict[str, Any]:
    print(f"[TOOL] subgraph({seed_ids}, k={k_hops})")
    res  = _get_adapter().subgraph(seed_ids, k_hops)
    _print_result(res)
    return res

def answer(text: str, evidence: List[str]):
    print(f"[TOOL] answer: {text} (evidence: {len(evidence)})")

    return f"FINAL ANSWER: {text}\nEVIDENCE: {evidence}"

def recurse(query: str, node_ids: List[str])-> str:
    """
    Recursively call the agent on a specific set of nodes (scope).
    This creates a new RLM instance focused ONLY on the provided nodes.
    """
    print(f"[TOOL] recurse(query='{query}', nodes={len(node_ids)})")

    scope = _get_scope_manager().scope_create(node_ids, description=f"Recursion for: {query}")
    nodes_data = _get_scope_manager().scope_nodes(scope.id)

    context_str = f"Context Scoped to {len(nodes_data)} nodes:\n"
    for n in nodes_data:
        content = n.get('text') or n.get('description') or str(n)
        context_str += f"-- Node {n.get('id')} ({n.get('_label', 'Node')}) --\n{content}\n\n"

    backend = os.getenv("RLM_BACKEND", "openai")
    model = os.getenv("RLM_MODEL", "gpt-4o")


    with RLM(
        backend=backend,
        backend_kwargs={"model_name": model},
        environment="local",
        environment_kwargs={
            "setup_code": "from rlm_graph.tools import *"
        }

    ) as sub_rlm:
        res = sub_rlm.completion(context_str, root_prompt=query)
        return f"Recursion Result: {res.response}"
    
def search_recurse(query: str, seed_ids: List[str], k_hops: int = 1) -> str:
    """
    Convenience tool:
    * expand from seed nodes via subgraph()
    * recurse on that expanded scope
    """
    print(f"[TOOL] search_recurse(query='{query[:50]}...', seeds={len(seed_ids)}, k={k_hops})")
    sg = subgraph(seed_ids, k_hops=k_hops)

    node_ids = []
    for n in sg.get("nodes", []):
        nid = n.get("id")
        if nid:
            node_ids.append(nid)

    # de-dup while preserving order
    seen = set()
    node_ids = [x for x in node_ids if not (x in seen or seen.add(x))]

    return recurse(query, node_ids)