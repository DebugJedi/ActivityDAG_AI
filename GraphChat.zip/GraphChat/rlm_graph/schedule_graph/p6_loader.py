from dataclasses import dataclass
import pandas as pd
from pathlib import Path


@dataclass
class P6Data:
    task: pd.DataFrame
    taskpred: pd.DataFrame
    project: pd.DataFrame
    wbs: pd.DataFrame
    

def load_p6(folder: str | Path) -> P6Data:
    folder = Path(folder)

    task = pd.read_csv(folder / "P01-1_TASK.csv")
    taskpred = pd.read_csv(folder / "P01-1_TASKPRED.csv")
    project = pd.read_csv(folder / "P01-1_PROJECT.csv")

    wbs_path = folder / "P01-1_PROJWBS.csv"
    wbs = pd.read_csv(wbs_path) if wbs_path.exists() else None

    task = task.dropna(subset=["task_id", "proj_id"])
    taskpred = taskpred.dropna(subset=["task_id", "pred_task_id"])

    for col in ["target_drtn_hr_cnt", "total_float_hr_cnt", "lag_hr_cnt"]:
        if col in task.columns:
            task[col] = pd.to_numeric(task[col], errors="coerce").fillna(0.0)
        if col in taskpred.columns:
            taskpred[col] = pd.to_numeric(taskpred[col], errors="coerce").fillna(0.0)
    
    for col in ["target_start_date", "target_end_date", "act_start_date", "act_end_date"]:
        if col in task.columns:
            task[col] = pd.to_datetime(task[col], errors="coerce")

    return P6Data(task=task, taskpred=taskpred, project=project, wbs=wbs)