import networkx as nx
import pandas as pd

ALLOWED_TASK_TYPES = {"TT_Task", "TT_Mile"}


class ScheduleGraph:
    def __init__(self, task_df: pd.DataFrame, pred_df: pd.DataFrame):
        self.task_df = task_df.copy()
        self.pred_df = pred_df.copy()
        self.G = nx.DiGraph()
        self._build()

    def _build(self):

        for _, t in self.task_df.iterrows():
            task_type = str(t.get("task_type", ""))
            if task_type and task_type not in ALLOWED_TASK_TYPES:
                continue
            
            tid = str(t["task_id"])
            self.G.add_node(
                tid,
                task_id=tid,
                task_code=str(t.get("task_code", "")),
                task_name=str(t.get("task_name", "")),
                duration_hr=float(t.get("target_drtn_hr_cnt", 0.0) or 0.0),
                total_float_hr=float(t.get("total_float_hr_cnt", 0.0) or 0.0),
                wbs_id=str(t.get("wbs_id", "")),
                status_code=str(t.get("status_code", "")),
                start=t.get("target_start_date"),
                finish=t.get("target_end_date"),
            )

        for _, r in self.pred_df.iterrows():
            pred = str(r["pred_task_id"])
            succ = str(r["task_id"])
            if pred not in self.G or succ not in self.G:
                continue

            self.G.add_edge(
                pred, succ, 
                rel=str(r.get("pred_type", "PR_FS")),
                lag_hr=float(r.get("lag_hr_cnt", 0.0) or 0.0),
            )

    def is_dag(self)-> bool:
        return nx.is_directed_acyclic_graph(self.G)
    
    def critical_tasks(self, eps: float=0.0):
        return [n for n,a in self.G.nodes(data=True) if a.get("total_float_hr", 0.0) <=eps]
    
    def near_critical_tasks(self, threshold_hr: float=40.0, eps: float=0.0):
        return [
            n for n, a in self.G.nodes(data=True)
            if eps < a.get("total_float_hr", 0.0)<=threshold_hr
        ]
    
    def critical_path_v1(self, eps: float=0.0):
        """
        Practial v1:
        Uses P6 total_float to define "critical"
        Finds the longest path within the critical subgraph using duration + lag
        Works best when the schedule is mostly FS
        """

        import math 

        crit = set(self.critical_tasks(eps=eps))
        H = self.G.subgraph(crit).copy()

        if H.number_of_nodes() == 0:
            return [], 0.0
        

        if not nx.is_directed_acyclic_graph(H):
            cycles=list(nx.simple_cycles(H)) 
            raise ValueError("Critical subgraph has cycles. Run logic checks / break cycles first.")
        
        topo = list(nx.topological_sort(H))
        dist = {n: float(H.nodes[n].get("duration_hr", 0.0))for n in topo}
        prev = {n: None for n in topo}

        for u in topo:
            for v in H.successors(u):
                lag = float(H.edges[u, v].get("lag_hr", 0.0))
                w = dist[u] + lag + float(H.nodes[v].get("duration_hr", 0.0))
                if w>dist.get(v, -math.inf):
                    dist[v] =w
                    prev[v] = u


        end = max(dist, key=dist.get)
        path = []
        cur = end 
        while cur is not None:
            path.append(cur)
            cur = prev[cur]
        path.reverse()

        return path, float(dist[end])
