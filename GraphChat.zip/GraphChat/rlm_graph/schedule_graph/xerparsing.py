import os
from xer_reader import XerReader
from glob import glob

xer_file = glob("data/*.xer")

class Extractor:
    def __init__(self):
        self.xer_file = glob("data/*.xer")
        self.export = r"data/schedule_data"

    def extractor(self):
        for file in self.xer_file:
            reader = XerReader(file)
            reader.to_csv(self.export, delimeter=',')
