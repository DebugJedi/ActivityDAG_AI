"""
Vector store for semantic search over graph chunks.
Uses sentence-transformers for embeddings and numpy for similarity search.
"""

import os 
import numpy as np
from typing import List, Dict, Any, Optional
from sentence_transformers import SentenceTransformer

class VectorStore:
    """
    In-memory vector store for semantic search.
    Loads chunks from the graph adapter and creates embeddings.
    """

    def __init__(self, adapter):
        from rlm_graph.config import get_embedding_model
        model_name = get_embedding_model()

        self.adapter = adapter
        self.model = SentenceTransformer(model_name)
        self.embeddings: Optional[np.ndarray]=None
        self.chunks: List[Dict[str, Any]] = []
        self.chunk_ids: List[str] = []
        self._initialized = False

    def initialized(self, force_recompute: bool=False):
        """
        Load chunks from the graph and compute or load embeddings.
        """
        if self._initialized and not force_recompute:
            return 
        from rlm_graph.config import get_embeddings_cache_path
        cache_path = get_embeddings_cache_path()

        all_chunks = self.adapter.node_find("Chunk", {}, limit=1000)
        if not all_chunks:
            print("[VectorStore] No chunks found in graph")
            self._initialized=True
            return 
        
        self.chunks = all_chunks
        self.chunk_ids = [c.get('id', '') for c in all_chunks]

        if not force_recompute and os.path.exists(cache_path):
            try:
                print(f"[VectorStore] Loading embeddings from cache: {cache_path}")
                data = np.load(cache_path, allow_pickle=True)
                cached_ids = data['ids'].tolist()
                cached_embeddings =data['embeddings']

                if cached_ids == self.chunk_ids:
                    self.embeddings = cached_embeddings
                    self._initialized = True
                    print(f"[VectorStore] Cache hit! Loaded {len(self.chunks)} chunks.")
                    return 
                else:
                    print("[VectorStore] Cache mismatch (graph changed). Recomputing...")
            except Exception as e:
                print(f"[VectorStore] Failed to load cache: {e}. Recomputing....")
        
        texts = []
        for chunk in all_chunks:
            text = chunk.get('text', '') or chunk.get('heading', '') or chunk.get('title', '') or str(chunk)
            texts.append(text)
        print(f"[VectorStore] Encoding {len(texts)} chunks....")
        self.embeddings = self.model.encode(texts, convert_to_numpy=True,show_progress_bar=False)

        try:
            print(f"[VectorStore] Saving embeddings to cache: {cache_path}")
            np.savez(cache_path, ids=np.array(self.chunk_ids), embeddings = self.embeddings)
        except Exception as e:
            print(f"[VectorStore] Failed to save cache: {e}")
        
        self._initialized = True
        print(f"[VectorStore] Initialized with {len(self.chunks)} chunks.")

    def search(self, query: str, top_k: int=5)-> List[Dict[str, Any]]:
        """
        Search for chunks most similar to the query.
        Returns list of chunks with similarity scores.
        """

        if not self._initialized:
            self.initialized()
        
        if self.embeddings is None or len(self.embeddings) ==0:
            return []
        
        query_embedding = self.model.encode([query], convert_to_numpy=True)[0]

        query_norm = query_embedding / np.linalg.norm(query_embedding)
        embeddings_norm = self.embeddings / np.linalg.norm(self.embeddings, axis=1, keepdims=True)

        similarities = np.dot(embeddings_norm, query_norm)

        top_indices = np.argsort(similarities)[::-1][:top_k]

        results = []
        for idx in top_indices:
            chunk = self.chunks[idx].copy()
            chunk['similarity_score'] = float(similarities[idx])
            results.append(chunk)

        return results

_VECTOR_STORE: Optional[VectorStore] =None

def get_vector_store(adapter)-> VectorStore:
    global _VECTOR_STORE
    if _VECTOR_STORE is None:
        _VECTOR_STORE = VectorStore(adapter)
    return _VECTOR_STORE
    
        