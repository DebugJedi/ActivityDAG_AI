from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional

class GraphAdapter(ABC):
    """
    Abstract base class for Graph Database adapters in RLM-Graph.
    Abstraction layer to switch between Kuzu, Neo4j, or others.
    """

    @abstractmethod
    def connect(self):
        """Establish connection to the database."""
        pass

    @abstractmethod
    def disconnect(self):
        """Close connection to the database."""
        pass

    @abstractmethod
    def node_get(self, node_id: str)-> Optional[Dict[str, Any]]:
        """Retrieve a node by its unique ID."""
        pass

    @abstractmethod
    def node_find(
        self,
        label: Optional[str]=None,
        properties: Optional[Dict[str, Any]]=None,
        limit: int=10
    )-> List[Dict[str, Any]]:
        """Find nodes matchings specific criteria."""
        pass

    @abstractmethod
    def neighbors(self,
                  node_id: str,
                  rel_type: Optional[str]=None,
                  direction: str="BOTH",
                  limit: int=50)->List[Dict[str, Any]]:
        """Get neighbors of a node."""
        pass

    @abstractmethod
    def execute_query(self,query: str, params: Optional[Dict[str, Any]]=None)-> List[Dict[str, Any]]:
        """Execute a raw Cypher query (or equivalent) and return results as a list of dicts."""
        pass

    @abstractmethod
    def add_node(self, label: str, properties: Dict[str, Any]):
        """Create or update a node."""
        pass

    @abstractmethod
    def add_edge(self, src_id: str, src_type: str, dst_id: str, dst_type: str, rel_type:str, properties: Dict[str, Any]=None):
        """Create an edge between two nodes."""
        pass

    @abstractmethod
    def subgraph(self, seed_node_ids: List[str], k_hops: int=1)-> Dict[str, Any]:
        """
        Get k-hp subgraph around seed nodes.
        Returns {'nodes': [...], 'edges': [...]}.
        """
        pass