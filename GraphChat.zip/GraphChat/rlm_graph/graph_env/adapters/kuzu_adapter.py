import kuzu
import os
import shutil
from typing import List, Dict, Any, Optional
from .base import GraphAdapter

class KuzuAdapter(GraphAdapter):
    """
    Kùzu DB implementation of GraphAdapter
    """

    def __init__(self, db_path: str=None, drop_existing: bool=False):
        if db_path is None:
            from rlm_graph.config import get_db_path
            db_path = get_db_path()
        self.db_path = db_path
        if drop_existing and os.path.exists(db_path):
            shutil.rmtree(db_path)
        
        self.db = kuzu.Database(db_path)
        self.conn = kuzu.Connection(self.db)
        self._ensure_schema()
    
    def connect(self):
        # Kuzu connection is established in init
        pass
    
    def disconnect(self):
        pass

    def _ensure_schema(self):
        """
        Intialized the schema based on PRD v1.
        We check if tables exist, if not create them.
        """

        def run_ddl(stmt):
            try:
                self.conn.execute(stmt)
            except RuntimeError as e:
                if "already exists" not in str(e):
                    pass
        
        # Node Tables
        run_ddl("CREATE NODE TABLE Doc(id STRING, title STRING, source STRING, timestamp STRING, PRIMARY KEY(id))")
        run_ddl("CREATE NODE TABLE Section(id STRING, doc_id STRING, heading STRING, section_order INT64, PRIMARY KEY(id))")
        run_ddl("CREATE NODE TABLE Chunk(id STRING, section_id STRING, text STRING, start_offset INT64, end_offset INT64, PRIMARY KEY(id))")
        run_ddl("CREATE NODE TABLE Entity(id STRING, name STRING, type STRING, aliases STRING[], PRIMARY KEY(id))")
        run_ddl("CREATE NODE TABLE Concept(id STRING, label STRING, PRIMARY KEY(id))")

        # Edge Tables
        run_ddl("CREATE REL TABLE HAS_SECTION(FROM Doc TO Section)")
        run_ddl("CREATE REL TABLE HAS_CHUNK(FROM Section TO Chunk)")
        run_ddl("CREATE REL TABLE MENTIONS(FROM Chunk TO Entity, confidence FLOAT)")
        run_ddl("CREATE REL TABLE RELATED_TO(FROM Entity TO Entity, confidence FLOAT)")
        run_ddl("CREATE REL TABLE HAS_TAG(FROM Entity TO Concept)")
        
        try:
            self.conn.execute("CREATE REL TABLE CITES_CHUNK(FROM Chunk TO Chunk)")
        except:
            pass

    def node_get(self, node_id: str)-> Optional[Dict[str, Any]]:
        tables = ["Doc", "Section", "Chunk", "Entity", "Concept"]
        for t in tables:
            query = f"MATCH (n:{t}) WHERE n.id = $id RETURN n"
            result = self.conn.execute(query, {"id": node_id})
            while result.has_next():
                row = self._row_to_dict(result.get_next(), result.get_column_names())
                return row.get('n', row)
        return None
    
    def node_find(self,
                  label: Optional[str]=None,
                  properties: Optional[Dict[str,Any]]=None,
                  limit: int=10)-> List[Dict[str,Any]]:
        lbl_str=f":{label}" if label else ""
        where_clauses = []
        params={}

        if properties:
            for k,v in properties.items():
                where_clauses.append(f"n.{k} = ${k}")
                params[k] = v

        where_str = " WHERE " + " AND ".join(where_clauses) if where_clauses else ""
        query = f"MATCH (n{lbl_str}){where_str} RETURN n LIMIT {limit}"

        resp =self.conn.execute(query, params)

        return [r.get('n', r) for r in self._result_to_list(resp)]
    
    def neighbors(self, node_id, rel_type = None, direction = "BOTH", limit = 50)-> List[Dict[str, Any]]:
        arrow_start = "<-" if direction == "IN" else "-"
        arrow_end = "->" if direction == "OUT" else "-"

        rel_str = f":{rel_type}" if rel_type else ""

        query = f"MATCH (a){arrow_start}[r{rel_str}]{arrow_end}(b) WHERE a.id = $id RETURN b LIMIT {limit}"
        resp = self.conn.execute(query, {"id": node_id})

        return [r.get('b', r) for r in self._result_to_list(resp)]
    
    def execute_query(self, query, params = None)-> List[Dict[str, Any]]:
        if params is None:
            params = {}
        resp = self.conn.execute(query, params)
        return self._result_to_list(resp)
    
    def add_node(self, label: str, properties: Dict[str, Any]):
        node_id = properties.get("id")
        if not node_id:
            raise ValueError("Node properties must contain 'id'")
        
        check_query = f"MATCH (n:{label}) WHERE n.id = $id RETURN n"
        if self.conn.execute(check_query, {"id": node_id}).has_next():
            return 
        props_str = ", ".join([f"{k}: ${k}" for k in properties.keys()])
        query = f"CREATE (n:{label} {{{props_str}}}) RETURN n"
        try:
            self.conn.execute(query, properties)
        except RuntimeError as e:
            if "already exists" not in str(e).lower():
                raise e
    
    def add_edge(self, src_id, src_type, dst_id, dst_type, rel_type, properties = None):
        if properties is None:
            properties = {}
        
        check_query = f"MATCH (a:{src_type})-[r:{rel_type}]->(b:{dst_type}) WHERE a.id = $src AND b.id = $dst RETURN r"
        if self.conn.execute(check_query, {"src": src_id, "dst": dst_id}).has_next():
            return 
        
        props_str = ""
        if properties:
            props_str = " {" +", ".join([f"{k}: ${k}" for k in properties.keys()]) +"}"
        
        query = f"""
        MATCH (a:{src_type}), (b:{dst_type})
        WHERE a.id = $src_id AND b.id = $dst_id
        CREATE (a)-[r:{rel_type}{props_str}]->(b)
        RETURN r
        """
        params = {"src_id":src_id, "dst_id": dst_id}
        params.update(properties)
        try:
            self.conn.execute(query, params)
        except RuntimeError:
            pass

    def subgraph(self, seed_node_ids, k_hops = 1):
        """BFS expansion to get subgraph."""
        nodes = {}
        edges = []
        vistied = set(seed_node_ids)
        frontier = set(seed_node_ids)

        for pid in seed_node_ids:
            n = self.node_get(pid)
            if n:
                nodes[pid]=n

        current_hop = 0

        while current_hop < k_hops and frontier:

            next_frontier = set()
            frontier_list = list(frontier)
            batch_size = 20

            for i in range(0, len(frontier), batch_size):
                batch = frontier_list[i:i+batch_size]

                or_clause = " OR ".join([f"a.id = '{bid}'" for bid in batch])
                query = f"MATCH (a)-[r]-(b) WHERE {or_clause} RETURN a, r, b"

                result = self.conn.execute(query)
                col_names = result.get_column_names()

                while result.has_next():
                    row_dict = self._row_to_dict(result.get_next(), col_names)

                    node_a = row_dict.get('a', row_dict)
                    rel = row_dict.get('r', row_dict)
                    node_b = row_dict.get('b', row_dict)
                    aid = node_a.get('id')
                    bid = node_b.get('id')

                    if aid and aid not in nodes:
                        nodes[aid] = node_a
                    if bid and bid not in nodes:
                        nodes[bid] = node_b

                    edges.append(rel)

                    if bid not in vistied:
                        next_frontier.add(bid)
                        vistied.add(bid)
                    if aid not in vistied:
                        pass

            frontier = next_frontier
            current_hop +=1


        return {"nodes": list(nodes.values()), "edges": edges}
    
    def _result_to_list(self, result)-> List[Dict[str, Any]]:
        out = []
        col_names = result.get_column_names()
        while result.has_next():
            out.append(self._row_to_dict(result.get_next(), col_names))
        return out 
    
    def _row_to_dict(self, row, col_names)->Dict[str, Any]:
        d={}
        for i, val in enumerate(row):
            d[col_names[i]] = val
        return d