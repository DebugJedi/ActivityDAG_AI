import re
from enum import Enum

class Intent(str, Enum):
    CRITICAL_PATH = "CRITICAL_PATH"
    FLOAT = "FLOAT"
    DURATION = "DURATION"
    DELAY = "DELAY"
    LOGIC = "LOGIC"
    SUMMARY = "SUMMARY"
    DEFINITION = "DEFINITION"
    UNKNOWN = "UNKNOWN"

def classify(q: str)-> Intent:
    s = q.lower().strip()

    if re.search(r"\bcritical path\b|\bcp\b", s):
        return Intent.CRITICAL_PATH
    
    if re.search(r"\bfloat\b|\btotal float\b|\bfree float\b|\bnear[- ]critical\b", s):
        return Intent.FLOAT
    
    if re.search(r"\bduration\b|\bfinish date\b|\bend date\b|\bhow long\b",s):
        return Intent.DURATION
    
    if re.search(r"\bdelay\b|\bslip\b|\bvariance\b|\bbaseline\b", s):
        return Intent.DELAY
    
    if re.search(r"\blogic\b|\bcycle\b|\bdangling\b|\bopen end\b",s):
        return Intent.LOGIC
    
    if re.search(r"^what is\b|define\b|explain\b", s):
        return Intent.DEFINITION
    
    if len(s)<6:
        return Intent.UNKNOWN
    
    return Intent.SUMMARY