import os


PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# DB_PATH = os.path.join(PROJECT_ROOT, "data")
DB_PATH = os.path.join(PROJECT_ROOT, "data", "kuzu_db.kuzu")

EMBEDDING_MODEL_NAME = 'sentence-transformers/all-MiniLM-L6-v2'
EMBEDDING_CACHE_PATH =  os.path.join(PROJECT_ROOT, "embeddings_cache.npz")


DEFAULT_MAX_ITERATIONS = 10
DEFAULT_BACKEND="openai"
DEFAULT_MODEL = 'gpt-4o'

AUDIT_LOG_PATH = os.path.join(PROJECT_ROOT, 'rlm_audit.jsonl')

def get_db_path():
    return os.environ.get("RLM_DB_PATH", DB_PATH)

def get_embedding_model():
    return os.environ.get("RLM_EMBEDDINGS_MODEL", EMBEDDING_MODEL_NAME)

def get_embeddings_cache_path():
    return os.environ.get("RLM_EMBEDDINGS_CACHE_PATH", EMBEDDING_CACHE_PATH)

print("CONFIG FILE:", __file__)
print("PROJECT_ROOT:", PROJECT_ROOT)
print("DB_PATH:", DB_PATH)