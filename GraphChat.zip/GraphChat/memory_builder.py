from rlm_graph.graphify.builder  import GraphBuilder
from rlm_graph.graph_env.adapters.kuzu_adapter import KuzuAdapter
from rlm_graph.config import get_db_path
import os
import shutil
from pathlib import Path
# from rlm_graph.schedule_graph import Extractor

def main():

    DB_PATH = get_db_path()
    DOCS_PATH = "./docs"
    

    parent_folder = Path(DB_PATH).parent
    
    if os.path.exists(parent_folder):
        print(f"Cleaning up existing DB at {DB_PATH}")
        shutil.rmtree(parent_folder)
    os.mkdir(parent_folder)
    
    

    print(f"Building graph from {DOCS_PATH}")
    builder = GraphBuilder(DB_PATH)
    builder.process_director(DOCS_PATH)

    print("\n=== Querying Graph =====")
    adapter = KuzuAdapter(DB_PATH)

    print("Node Counts: ")

    for lbl in ["Doc", "Section", "Chunk", "Entity"]:
        res = adapter.conn.execute(f"MATCH (n:{lbl}) RETURN count(n)").get_next()
        print(f"    {lbl}: {res[0]}")
    
    print("\nFinding entities with 'Graph' in name:")
    query = "MATCH (e:Entity) WHERE e.name CONTAINS 'Graph' RETURN e LIMIT 5"
    results = adapter.execute_query(query)
    for r in results:
        ent = r['e']
        print(f"    - [{ent['type']}] {ent['name']}")

    # print("\nInspecting first Doc:")
    # doc_res = adapter.execute_query("MATCH (d:Doc) RETURN d LIMIT 1")
    # if doc_res:
    #     doc_node = doc_res[0]['d']
    #     doc_id = doc_node['id']
    #     print(f"    Doc: {doc_node['title']}")

    #     secs = adapter.neighbors(doc_id, rel_type="HAS_SECTION", direction="OUT")
    #     print(f"    Sections found: {len(secs)}")
    #     for i, s, in enumerate(secs[:3]):
    #         s_node = s['b'] if 'b' in s else s
    #         print(f"    {i+1}. {s_node.get('heading', 'No Heading')}")
    
if __name__ == "__main__":
    main()